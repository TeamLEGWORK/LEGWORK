# gw-calcs
simple package for gravitational wave calculations 
